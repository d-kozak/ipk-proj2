//
// Created by david on 30.3.16.
//

#ifndef IPK_PROJ2_SERVER_H
#define IPK_PROJ2_SERVER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdexcept>

#include "iostream"

#include "socket_handler.h"
#include "protokol_parser.h"

#endif //IPK_PROJ2_SERVER_H
