//
// Created by david on 30.3.16.
//

#ifndef IPK_PROJ2_CLIENT_H
#define IPK_PROJ2_CLIENT_H

#include <iostream>
#include <iterator>
#include <fstream>
#include <vector>
#include <algorithm>

#include "socket_handler.h"
#include "protokol_parser.h"

#endif //IPK_PROJ2_CLIENT_H
