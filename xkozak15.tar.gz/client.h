//
// Created by david on 30.3.16.
//

#ifndef IPK_PROJ2_CLIENT_H
#define IPK_PROJ2_CLIENT_H

#endif //IPK_PROJ2_CLIENT_H
